[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f7c51539e67b483bb8d7749acca51d3a)](https://app.codacy.com/gh/H1M4N5HU0P/MAFIA-BOT/dashboard)
[![Python 3.6](https://img.shields.io/badge/Python-3.6%20or%20newer-blue.svg)](https://www.python.org/downloads/release/python-360/)
[![Contact Me](https://img.shields.io/badge/Telegram-Contact%20Me-informational)](https://t.me/daredevil_king)
[![Contact Me](https://img.shields.io/badge/Telegram-Contact%20Me-informational)](https://t.me/@Legendl_Mr_Hacker)


# ALEX-UB-USERBOT#ULTRA HIGH
This is a userbot made for telegram. I made this userbot with help of all other userbots available in telegram. All credits goes to its Respective Owners....
THIS USERBOT IS DESIGNED BY @daredevil_king WITH THE HELP OF @Legendl_Mr_Hacker --MY FRIEND
THE HELPERS ARE AND WHOM I WANAN GIVE CREDIT ARE 
@ALEXUSERBOT_YOURDAD


ALEX-UB    (userbot) made by @daredevil_king. Supported by respective hellbot owner @Kraken_The_Badass  and mafia bot owner @H1M4N5HU0P. Join for update related info channel and group :-  THANKS FOR VISITING OUR REPO💖

![photo_2021-10-03_07-40-19](https://user-images.githubusercontent.com/87700009/137922553-4a55a437-7a01-4667-86e7-fdbaf099c7d1.jpg)


# The owner would not be responsible for any kind of bans due to the bot...


<details>

  <summary> • FOR ANY QUERY • </summary>
<h2 align="center"> <a href="https://t.me/Alex_userbot_support">☢️JOIN ALEX-UB SUPPORT☢️</a></h2>

</details>


# FORK AT YOUR OWN RISK

<details>

  <summary> • INSTALLING • </summary>

### The Easy Way

<h4>⚜️ DEPLOY TO HEROKU ⚜️</h4>
  
  [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Dhrubamoy/ALEX-UB)


</details>



<details>

  <summary> • MY HELPER • </summary>
<h2 align="center"> <a href="https://t.me/about_k_4_king/6">☢️CONTACT LEGEND-LX☢️</a></h2>

</details>



<details>

  <summary> • CONTACT ME • </summary>
<h2 align="center"> <a href="https://t.me/about_k_4_king/2">☢️ME☢️</a></h2>

</details>



<details>

  <summary> • CONTACT BOT OWNER • </summary>
<h2 align="center"> <a href="https://t.me/about_k_4_king/7">☢️ALONE ADARSH☢️</a></h2>

</details>




# THE MAIN AND RESPECTIVE OWNER FROM WHERE SOME OF THE SOME BOT FILES TAKEN ARE

<details>

  <summary> • MAFIABOT OWNER • </summary>
<h2 align="center"> <a href="https://t.me/about_k_4_king/8">☢️MAFIABOT☢️</a></h2>

</details>



<details>

  <summary> • HELLBOT OWNER • </summary>
<h2 align="center"> <a href="https://t.me/about_k_4_king/9">☢️HELLBOT OWNER☢️</a></h2>

</details>


